const express = require('express');
const morgan = require('morgan');
const mongoose = require('mongoose');
const Account = require('./models/account');
const Session = require('./models/session');

// express app
const app = express();

// connect to mongodb
const dbURI= 'mongodb+srv://eric:123321@hackthenorth.nvyu0.mongodb.net/hackthenorth?retryWrites=true&w=majority';
mongoose.connect(dbURI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then((result) => app.listen(3000))
    .catch((err) => console.log(err));

// register view engine
app.set('view engine', 'ejs');

// middleware & static files
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true}));
app.use(morgan('dev'));

app.get('/home', (req, res) => {
    res.render('home');
});

app.get('/index', (req, res) => {
    res.render('index');
});

app.get('/lecturePage', (req, res) => {
    res.render('lecturePage');
});

app.get('/register', (req, res) => {
    res.render('register');
});

app.get('/userNotes', (req, res) => {
    res.render('userNotes');
});

app.get('/userStats', (req, res) => {
    res.render('userStats');
});

app.get('/voicetesting', (req, res) => {
    res.render('voicetesting');
});

app.post('/accounts', (req, res) => {
    const account = new Account(req.body);

    account.save()
        .then((result) => {
            res.redirect('/home')
        })
        .catch((err) => {
            console.log(err);
        })
})

app.post('/sessions', (req, res) => {
    const session = new Session(req.body);

    session.save()
        .then((result) => {
            res.redirect('/userStats')
        })
        .catch((err) => {
            console.log(err);
        })
})

app.use((req, res) => {
    res.status(404).render('404', {title: '404'});
});