const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const sessionSchema = new Schema({
    username: {
        type: String
    },
    distractioncount: {
        type: Number
    },
    angry: {
        type: Number
    },
    disgusted: {
        type: Number
    },
    fearful: {
        type: Number
    },
    happy: {
        type: Number
    },
    neutral: {
        type: Number
    },
    surprised: {
        type: Number
    },
    sad: {
        type: Number
    }
}, { timestamps: true });

const Session = mongoose.model('Session', sessionSchema);
module.exports = Session;